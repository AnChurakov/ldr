﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcState.Models;

namespace MvcState.Controllers
{
    

    public class HomeController : Controller
    {
        private const string StateCookieName = "State";

        public ActionResult Index()
        {
            return this.View();
        }

        #region UrlState
        public ActionResult UrlState(int? state)
        {   
            this.ViewBag.State = state.HasValue ? state.Value : 1;
            return this.View();
        }
         #endregion

        #region PageState
        
        public ActionResult PageState()
        {
            return this.View(new PageStateViewModel() { State = 1});
        }

        [HttpPost]
        public ActionResult PageState(PageStateViewModel model)
        {
            model.State++;
            ModelState.Remove("State");
            return this.View(model);
        }

        #endregion

        #region CookiesState
        
        public ActionResult CookiesState()
        {
            var stateCookie = this.Request.Cookies[StateCookieName];
            if (stateCookie == null)
            {
                stateCookie = new HttpCookie(StateCookieName, "0");
                
                Response.AppendCookie(stateCookie);
            }

            stateCookie.Expires = DateTime.Now.AddMinutes(5);
            var stateValue = int.Parse(stateCookie.Value);
            stateValue++;
            ViewBag.State = stateValue;

            stateCookie.Value = stateValue.ToString();
            Response.SetCookie(stateCookie);

            return this.View(new CookiesStateViewModel());
        }

        [HttpPost]
        public ActionResult CookiesState(CookiesStateViewModel model)
        {
            var stateCookie = this.Request.Cookies[StateCookieName];
            if (stateCookie == null)
            {
                stateCookie = new HttpCookie(StateCookieName, "0");
                Response.AppendCookie(stateCookie);
            }

            stateCookie.Expires = DateTime.Now.AddMinutes(5);
            var stateValue = int.Parse(stateCookie.Value);
            stateValue++;
            ViewBag.State = stateValue;
           
            stateCookie.Value = stateValue.ToString();
            Response.SetCookie(stateCookie);

            return this.View(model);
        }

        #endregion

        #region ServerSessionState
       
        public ActionResult ServerSessionState()
        {
            var state = State;
            ViewBag.State = state;
            state++;

            State = state;

            return this.View();
        }

        private int State { 
            get
            {
                return (int)(Session["State"] ?? 1);
            }

            set
            {
                Session["State"] = value;
            }
        }

        #endregion
    }
}

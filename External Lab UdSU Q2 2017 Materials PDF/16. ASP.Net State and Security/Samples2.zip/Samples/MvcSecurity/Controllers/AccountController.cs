﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MvcSecurity.Models;

namespace MvcSecurity.Controllers
{


	public class AccountController : Controller
	{
		//
		// GET: /Account/

		public ActionResult LogOn()
		{
			return View();
		}

		[HttpPost]
		public ActionResult LogOn(UserPasswordViewModel userAndPassword, string ReturnUrl)
		{
			if (!string.IsNullOrEmpty(userAndPassword.User) && !string.IsNullOrEmpty(userAndPassword.Password))
			{
				FormsAuthentication.SetAuthCookie(userAndPassword.User, false);

				return Redirect(ReturnUrl);
			}

			return View(userAndPassword);
		}

		public ActionResult LogOff()
		{
			FormsAuthentication.SignOut();

			return Redirect("~/");
		}
	}


	
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcState.Models
{
    public class CookiesStateViewModel
    {
        public string Field { get; set; }
    }
}
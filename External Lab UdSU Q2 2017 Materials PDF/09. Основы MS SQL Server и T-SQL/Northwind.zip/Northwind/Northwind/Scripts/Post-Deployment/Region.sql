﻿INSERT [Northwind].[Region] ([RegionID], [RegionDescription]) VALUES (1, N'Eastern                                           ')
INSERT [Northwind].[Region] ([RegionID], [RegionDescription]) VALUES (2, N'Western                                           ')
INSERT [Northwind].[Region] ([RegionID], [RegionDescription]) VALUES (3, N'Northern                                          ')
INSERT [Northwind].[Region] ([RegionID], [RegionDescription]) VALUES (4, N'Southern                                          ')

﻿CREATE NONCLUSTERED INDEX [OrderDate] ON [Northwind].[Orders] 
(
	[OrderDate] ASC
)
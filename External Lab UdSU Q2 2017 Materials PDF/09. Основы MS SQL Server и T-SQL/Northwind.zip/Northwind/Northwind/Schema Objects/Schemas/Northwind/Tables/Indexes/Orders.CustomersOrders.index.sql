﻿CREATE NONCLUSTERED INDEX [CustomersOrders] ON [Northwind].[Orders] 
(
	[CustomerID] ASC
)
﻿CREATE NONCLUSTERED INDEX [Region] ON [Northwind].[Customers] 
(
	[Region] ASC
)
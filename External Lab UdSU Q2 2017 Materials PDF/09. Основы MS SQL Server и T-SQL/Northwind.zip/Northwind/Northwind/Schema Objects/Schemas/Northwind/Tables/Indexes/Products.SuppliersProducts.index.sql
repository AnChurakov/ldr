﻿CREATE NONCLUSTERED INDEX [SuppliersProducts] ON [Northwind].[Products] 
(
	[SupplierID] ASC
)
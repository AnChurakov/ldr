﻿CREATE NONCLUSTERED INDEX [OrdersOrder_Details] ON [Northwind].[Order Details] 
(
	[OrderID] ASC
)
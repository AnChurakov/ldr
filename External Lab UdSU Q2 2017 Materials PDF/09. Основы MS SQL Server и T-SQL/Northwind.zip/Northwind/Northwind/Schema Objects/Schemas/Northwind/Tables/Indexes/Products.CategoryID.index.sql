﻿CREATE NONCLUSTERED INDEX [CategoryID] ON [Northwind].[Products] 
(
	[CategoryID] ASC
)
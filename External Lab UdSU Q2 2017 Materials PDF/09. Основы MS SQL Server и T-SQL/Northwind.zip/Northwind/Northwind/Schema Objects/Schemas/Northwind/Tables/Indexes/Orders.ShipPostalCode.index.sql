﻿CREATE NONCLUSTERED INDEX [ShipPostalCode] ON [Northwind].[Orders] 
(
	[ShipPostalCode] ASC
)
﻿CREATE NONCLUSTERED INDEX [CategoryName] ON [Northwind].[Categories] 
(
	[CategoryName] ASC
)
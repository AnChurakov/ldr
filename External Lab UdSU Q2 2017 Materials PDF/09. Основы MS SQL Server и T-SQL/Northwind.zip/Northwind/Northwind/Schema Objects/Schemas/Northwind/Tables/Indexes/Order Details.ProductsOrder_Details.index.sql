﻿CREATE NONCLUSTERED INDEX [ProductsOrder_Details] ON [Northwind].[Order Details] 
(
	[ProductID] ASC
)
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pascal
{
    class Program
    {

        //static void Main(string[] args)
        //{
        //    int[] arr = { 1, 1, -2, 2, -3, 2, 4, 2, 5, 16, 16, 23, 12, 321, 2, 12 };

        //    foreach (var i in arr.Distinct())
        //    {
        //        Console.Write(" {0}", i);
        //    }
        //    Console.ReadKey();
        //}

        #region Различные элементы массива
        //static void Main(string[] args)
        //{
        //    int[] arr = { 1, 1, -2, 2, -3, 2, 4, 2, 5, 16, 16, 23, 12, 321, 2, 12 };
        //    int[] arrDistinct = arr.Distinct().ToArray();

        //    Console.Write(" {0}. \nРазличных элементов: {1} ({2})", string.Join(" ", arr), arrDistinct.Count(), string.Join(" ", arrDistinct));
        //    Console.ReadKey();
        //}
        #endregion

        #region Паскаль
        //static void Main(string[] args)
        //{
        //    int i, n = 0, c;
        //    ConsoleKeyInfo key;

        //    do
        //    {
        //        do
        //        {
        //            Console.WriteLine("Введите нужное количество строк треугольника Паскаля:");
        //            int.TryParse(Console.ReadLine(), out n);
        //        } while (n <= 0);

        //        for (i = 0; i < n; i++)
        //        {
        //            for (c = 0; c <= (n - i); c++)
        //            // создаём после каждой строки n-i отступов от левой стороны консоли, чем ниже строка, тем меньше отсутп
        //            {
        //                Console.Write(" ");
        //            }
        //            for (c = 0; c <= i; c++)
        //            {
        //                Console.Write(" "); // создаём пробелы между элементами треугольника
        //                Console.Write(factorial(i) / (factorial(c) * factorial(i - c)));
        //                //формула вычисления элементов треугольника
        //            }
        //            Console.WriteLine();
        //            Console.WriteLine(); // после каждой строки с числами отступаем две пустые строчки
        //        }

        //        Console.WriteLine("Повторить эксперимент (y)?");
        //        key = Console.ReadKey();

        //        Console.WriteLine();

        //    } while (key.Key == ConsoleKey.Y);
        //}

        public static float factorial(int n)
        {
            float i, x = 1;
            for (i = 1; i <= n; i++)
            {
                x *= i;
            }
            return x;
        }

        #endregion

        #region Фибоначи

        //private static void Main(string[] args)
        //{
        //    int i, j, n = 0, c;
        //    ConsoleKeyInfo key;
        //    do
        //    {
        //        do
        //        {
        //            Console.WriteLine("Введите нужное количество элементов последовательности Фибоначи:");
        //            int.TryParse(Console.ReadLine(), out n);
        //        } while (n <= 0);

        //        c = 0;
        //        j = 1;
        //        i = 1;
        //        do
        //        {
        //            Console.Write("{0} ", i);
        //            j = i - j;

        //            c++;

        //            if (c >= n)
        //            {
        //                break;
        //            }
        //            i += j;
        //        } while (i > 0);

        //        if (i <= 0)
        //        {
        //            Console.WriteLine("\nПроизошло переполнение переменной i. Цикл прерван на {0} итерации.", c);
        //        }

        //        Console.WriteLine("Повторить эксперимент (y)?");
        //        key = Console.ReadKey();

        //        Console.WriteLine();

        //    } while (key.Key == ConsoleKey.Y);
        //}
        
        #endregion
    }

}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
	internal class Program
	{
		private static void Main(string[] args)
		{
            StringCompare();
            Console.ReadKey();
        }

		private static Int32 NumTimesWordAppearsEquals(String word, String[] wordlist)
		{
			Int32 count = 0;
			for (Int32 wordnum = 0; wordnum < wordlist.Length; wordnum++)
			{
				if (word.Equals(wordlist[wordnum], StringComparison.Ordinal))
					count++;
			}
			return count;
		}

		private static Int32 NumTimesWordAppearsIntern(String word, String[] wordlist)
		{
			// В этом методе предполагается, что все элементы в wordlist
			// ссылаются на интернированные строки.
			word = String.Intern(word);
			Int32 count = 0;
			for (Int32 wordnum = 0; wordnum < wordlist.Length; wordnum++)
			{
				if (Object.ReferenceEquals(word, wordlist[wordnum]))
					count++;
			}
			return count;
		}

		/// <summary>
		/// Note that the strings "encyclopædia" and "encyclopedia" are considered equivalent in the en-US 
        /// culture but not in the Sami (Northern Sweden) culture.
		/// </summary>
		private static void StringCompare()
		{
			String[] cultureNames = {"en-US", "se-SE"};
			String[] strings1 =
			{
				"case", "encyclopædia",
				"encyclopædia", "Archæology"
			};
			String[] strings2 =
			{
				"Case", "encyclopaedia",
				"encyclopedia", "ARCHÆOLOGY"
			};
			StringComparison[] comparisons = (StringComparison[]) Enum.GetValues(typeof (StringComparison));

			foreach (var cultureName in cultureNames)
			{
				Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureName);
				Console.WriteLine("Current Culture: {0}", CultureInfo.CurrentCulture.Name);
				for (int ctr = 0; ctr <= strings1.GetUpperBound(0); ctr++)
				{
					foreach (var comparison in comparisons)
					{ 
						Console.WriteLine("   {0} = {1} ({2}): {3}", strings1[ctr], strings2[ctr], comparison, String.Equals(strings1[ctr], strings2[ctr], comparison));
					}

					Console.WriteLine();
				}
				Console.WriteLine();
			}
		}
	}
}
